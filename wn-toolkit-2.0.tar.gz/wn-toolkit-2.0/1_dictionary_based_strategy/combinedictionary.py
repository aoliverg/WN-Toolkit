#copyright Antoni Oliver (2012) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

#vesion 2.0

import re
import codecs
import sys
import os.path

print sys.argv
diccionari={}
fitxersortida=sys.argv.pop()
if os.path.exists(fitxersortida):
    print "Output file already exists. Use another file or delete it first"
    sys.exit()
fs=codecs.open(fitxersortida,"w",encoding="utf-8")
for fitxer in sys.argv[1:]:
    fd=codecs.open(fitxer,"r",encoding="utf-8")
    while 1:
        linia=fd.readline()
        if not linia:
            break
        linia=linia.rstrip()
        linia=linia.lstrip()
        camps=linia.split("\t")
        if len(camps)==3:
            l1=camps[0]
            pos=camps[1]
            l2=camps[2]
            l1pos=l1+":"+pos
            if diccionari.has_key(l1pos):
                traduccions=diccionari[l1pos].split(":")
                if not l2 in traduccions:
                    traduccions.append(l2)
                    diccionari[l1pos]=":".join(traduccions)
            else:
                diccionari[l1pos]=l2

keys=diccionari.keys()
keys.sort()
for key in keys:
	cadena=key.split(":")[0]+"\t"+key.split(":")[1]+"\t"+diccionari[key]
	print cadena
	fs.write(cadena+"\n")


#FALTA IMPLEMENTAR EL PROGRAMA
