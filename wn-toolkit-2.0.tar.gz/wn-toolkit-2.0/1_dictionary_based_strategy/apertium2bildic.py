# copyright Marta Contreras (2012) (Universitat Oberta de Catalunya - mcontrerasf@uoc.edu) 
# and Antoni Oliver (2012) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /usr/bin/python
# -*- coding: utf-8 -*-


import xml.dom.minidom
from xml.dom.minidom import Node
import sys, argparse
import codecs
import csv, operator
import os


''''''''''''''''''''''''''''''' FUNCTIONS '''''''''''''''''''''''''''''''


def check_in (list1, list2):
	res = ""
	for par in list1.strip().split(":"):
		if par not in list2.strip().split(":"): 
			if res == "": res = par
			else: res = res + ":" + par
	return res


# re-read the output file to reorder it, delete repeated 
# and aggregate translations within the same word 
def order_file():
	diccionari={}
	of = codecs.open("temp-file.txt","r",encoding="utf-8")
	sortida=codecs.open(args.outputfile,"w",encoding="utf-8")
	while 1:
		linia=of.readline()
		if not linia:
			break
		linia=linia.rstrip()
		camps=linia.split("\t")
		clau=camps[0]+":"+camps[1]
		valor=camps[2]
		if diccionari.has_key(clau):
			paraules=diccionari[clau].split(".")
			if not valor in paraules:
				diccionari[clau]=diccionari[clau]+":"+valor
		else:
			diccionari[clau]=valor
	for clau in sorted(diccionari.iterkeys()):
		camps=clau.split(":")
		cadena=camps[0]+"\t"+camps[1]+"\t"+diccionari[clau]
		sortida.write(cadena+"\n")


		

# save the result (english variant + category + list of translations) into an output file or database
def save_data (par1, categ1, trad1,reverse):
	res=""
	try:
		if reverse:
			res = trad1.strip() + "\t" + categ1 + "\t" + par1.strip() + "\n"
		else:
			res = par1.strip() + "\t" + categ1 + "\t" + trad1.strip() + "\n"
		of.write(res)
	except: print "ERROR-SAVE", res, sys.exc_info()


# convert the category (POS) to the standard Wordnet categories  
def convert (categ):
	if categ == "n": return "n" 
	elif categ == "np": return "np"
	elif categ == "adj": return "a"
	elif categ == "adv": return "r"
	elif categ == "vbser" or categ == "vbhaver" or categ == "vblex" or categ == "vmod" or categ == "vaux": return "v"
	else: return ""



'''''''''''''''''''''   MAIN '''''''''''''''''''''''''''''

# command line options
parser = argparse.ArgumentParser(description='Creates a bilingual dictionary from an Apertium\'s transfer dictionary', version='%prog 2.0')
parser.add_argument("-a","--apertium",dest="apertium",required=True,
                   help='the name of the file of the apertium dictionary', metavar="FILE")
parser.add_argument("-o", "--output", dest="outputfile",required=True,
                  help="a file to write the results", metavar="FILE") 
parser.add_argument("-r","--reverse",dest="reverse",default=False,action='store_true',
                   help='reverses the dictionary')                  
args = parser.parse_args()

if (args.apertium==None and args.outputfile==None):
    print "No options provided. Use -h to get help"
    sys.exit()

if args.apertium==None:
	print "No apertium dictionary provided. Use -h to get help"
	sys.exit()

if args.outputfile==None:
	print "No outputfile provided. Use -h to get help"
	sys.exit()

of = codecs.open("temp-file.txt","w",encoding="utf-8")


# xml APERTIUM file
doc = xml.dom.minidom.parse(args.apertium)


# read xml APERTIUM file
try:

	for node in doc.getElementsByTagName("e"):

 		categ = ""
  		par = ""
  		trad = ""

		L = node.getElementsByTagName("l")
		for node2 in L:
			for node3 in node2.childNodes:     
				if node3.nodeType == Node.TEXT_NODE:
			  		par += node3.data + " "
				else: categ = node3.getAttribute("n")
				for node4 in node3.childNodes:
			  		if node4.nodeType == Node.TEXT_NODE:
			    			par += node4.data + " "

  		R = node.getElementsByTagName("r")
		for node2 in R:
  			for node3 in node2.childNodes:
				if node3.nodeType == Node.TEXT_NODE:
					trad += node3.data + " "
				for node4 in node3.childNodes:
					if node4.nodeType == Node.TEXT_NODE:
						trad += node4.data + " "

  		if par == "" or trad == "": continue

		categ = convert (categ)
		if categ == "": continue

		save_data (par, categ, trad, args.reverse)
		    

except: print "ERROR", sys.exc_info()
	
    
# close 
#of.close()
order_file()

