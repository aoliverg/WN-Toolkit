# copyright Marta Contreras (2012) (Universitat Oberta de Catalunya - mcontrerasf@uoc.edu)

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /usr/bin/python
# -*- coding: utf-8 -*-


import xml.dom.minidom
from xml.dom.minidom import Node
import sys, argparse
import codecs
import csv, operator
import os, glob
import re

''''''''''''''''''''''''''''''' FUNCTIONS '''''''''''''''''''''''''''''''
class TBXTools:
	def __init__(self):
		self.termbase={}
		self.fi=""
		self.firsline=""
		self.encoding=""
		self.contid=0
		return None
	def numoftranslations(self,i,langs):
		self.conttrans=0
		for self.lang in langs:
			keylang=str(i)+":"+self.lang
			if self.termbase.has_key(keylang):
				self.conttrans+=1
		return(self.conttrans)
		
	
	def normalitza(self,term):
		m=re.findall("&#([0-9]+);",term)
		for f in m:
			c="&#"+str(f)+";"
			try:
				term=term.replace(c,unichr(int(f)))
			except:
				print "ERROR",term,f,c,unichr(int(f))
		return(term)	

	def write_town(self,file_OT,sl,tl,defaultpos):
		self.diccionari={}
		self.OTf=codecs.open(file_OT,"w",encoding="utf-8")
		for self.i in range(1,len(self.termbase.keys())):
			self.keysl=str(self.i)+":"+sl
			self.keytl=str(self.i)+":"+tl
			self.keyarea=str(self.i)+":area"
			if self.termbase.has_key(self.keysl) and self.termbase.has_key(self.keytl):
				self.termssl=self.termbase[self.keysl].split(":")
				for self.slt in self.termssl:
					sourceterm=self.slt.decode("utf-8")
					sourceterm=sourceterm.rstrip()
					sourceterm=sourceterm.lstrip()
					targetterms=self.termbase[self.keytl].decode("utf-8").split(":")
					if not sourceterm=="":
						for targetterm in targetterms:
							if self.diccionari.has_key(sourceterm):
								paraules=self.diccionari[sourceterm].split(":")
								if not targetterm in paraules:
									self.diccionari[sourceterm]=self.diccionari[sourceterm]+":"+targetterm
							else:
								self.diccionari[sourceterm]=targetterm
		for clau in sorted(self.diccionari.iterkeys()):
			cadena=clau+"\t"+defaultpos+"\t"+self.diccionari[clau]
			self.OTf.write(cadena+"\n")
		self.OTf.close()

	def write_OT(self,file_OT,sl,tl):
		self.OTf=codecs.open(file_OT,"w",encoding="utf-8")
		for self.i in range(1,len(self.termbase.keys())):
			self.keysl=str(self.i)+":"+sl
			self.keytl=str(self.i)+":"+tl
			self.keyarea=str(self.i)+":area"
			if self.termbase.has_key(self.keysl) and self.termbase.has_key(self.keytl):
				self.termssl=self.termbase[self.keysl].split(":")
				for self.slt in self.termssl:
					self.cadenaOT=self.slt.decode("utf-8")+"\t"+self.termbase[self.keytl].decode("utf-8").replace(":",", ")+"\t"+self.termbase[self.keyarea].decode("utf-8")+"\n"
					self.OTf.write(self.cadenaOT)#.decode("utf-8"))
		self.OTf.close()
	def getLanguages(self):
		self.langshash={}
		for self.element in self.termbase.keys():
			self.campselements=self.element.split(":")
			if not self.campselements[1]=="area":
				self.langshash[self.campselements[1]]=1
		return(self.langshash.keys())	
	def write_TBX(self,file_TBX,languages):
		self.cont2=0
		self.TBXf=codecs.open(file_TBX,"w",encoding="utf-8")
		self.TBXf.write("<?xml version=\"1.0\" ?>\n")
		self.TBXf.write("<martif type=\"TBX\" xml:lang=\"en\">\n")
		self.TBXf.write("  <text>\n")
		self.TBXf.write("    <body>\n")
		for self.i in range(1,len(self.termbase.keys())):
			self.keyarea=str(self.i)+":area"
			if self.termbase.has_key(self.keyarea) and self.numoftranslations(self.i,languages)>=2:
				self.subjectfield=self.termbase[self.keyarea]
				self.cont2+=1
				self.cadena="      <termEntry id=\""+str(self.cont2)+"\">"
				self.TBXf.write(self.cadena+"\n")
				self.cadena="        <descrip type=\"subjectField\">"
				self.TBXf.write(self.cadena+"\n")
				self.keyarea=str(self.i)+":area"
				self.TBXf.write("          "+self.subjectfield.decode("utf-8")+"\n")
				self.TBXf.write("        </descrip>\n")
				for self.lang in languages:					
					self.keylang=str(self.i)+":"+self.lang
					if self.termbase.has_key(self.keylang):
						#comenca modificacio
						self.termssl=self.termbase[self.keylang].split(":")
						for self.slt in self.termssl:
						#acaba modificacio
							self.cadena="	    <langSet xml:lang=\""+self.lang+"\">"
							self.TBXf.write(self.cadena+"\n")
							self.TBXf.write("	      <tig>\n")
							self.TBXf.write("	        <term>\n")
							#self.cadena="	          "+self.termbase[self.keylang].decode("utf-8")
							self.cadena="	          "+self.slt.decode("utf-8")
							self.TBXf.write(self.cadena+"\n")
							self.TBXf.write("	        </term>\n")
							self.TBXf.write("	      </tig>\n")
							self.TBXf.write("	    </langSet>\n")						
				self.TBXf.write("	  </termEntry>\n")
		self.TBXf.write("    </body>\n")
		self.TBXf.write("  </text>\n")
		self.TBXf.write("</martif>\n")
		
	
	def read_TO(self,file_TO):
		self.fi=codecs.open(file_TO,"r",encoding="utf-8")
		self.firstline=self.fi.readline()
		if self.firstline.find("ISO-8859-1")>-1:
			self.encoding="iso-8859-1"
		elif self.firstline.find("UTF-8")>-1:
			self.encoding="utf-8"
		self.fi.close()
		if self.encoding=="utf-8":
			self.fi=codecs.open(file_TO,"r",encoding="utf-8")
		elif self.encoding=="iso-8859-1":
			self.fi=codecs.open(file_TO,"r",encoding="iso-8859-1")
		self.lines=self.fi.readlines()
		self.inFitxa=False
		self.inFitxa=False
		self.area=""
		for self.line in self.lines:
			self.line=self.line.rstrip()
			self.line=self.line.replace("<![CDATA[","")
			self.line=self.line.replace("]]>","")
			if self.line.find("<fitxa")>-1:
				self.inFitxa=True
				self.contid+=1
			if self.line.find("</fitxa>") > -1:
				selfinFitxa=False
				self.area=""
			if self.line.find("areatematica")>-1 and self.inFitxa:
				try:
					self.m=re.search("<areatematica>(.*)</areatematica>",self.line)
					self.area=self.m.group(1)
					self.area=self.normalitza(self.area).encode("utf-8")
					self.key=str(str(self.contid)+":area")
					self.termbase[self.key]=str(self.area)
				except Exception:
					self.area=file_TO[0:-4]
					print traceback.format_exc()
			if self.line.find("denominacio")>-1 and self.inFitxa:
				self.m=re.search("<denominacio llengua=\"(.+?)\" (.*)>(.*)</denominacio>",self.line)
				self.lang=self.m.group(1)
				self.term=self.m.group(3)
				self.term=self.normalitza(self.term)
				self.key=str(str(self.contid)+":"+self.lang)
				if self.termbase.has_key(self.key):
					self.termbase[self.key]+=":"+str(self.term.encode("utf-8"))
				else:
					self.termbase[self.key]=str(self.term.encode("utf-8"))
	def fromwikipedia(self,subjects,langs):
		self.contid=0
		try:
			conn = MySQLdb.connect (host = "cml.uoc.edu",
				user = "wikipedia",
				passwd = "wikipedialpg",
			    db = "wikipedia2tbx")
		except MySQLdb.Error, e:
			print "Error %d: %s" % (e.args[0], e.args[1])
			sys.exit (1)
		cursor = conn.cursor ()
		cursor2 = conn.cursor ()
		conn.set_character_set('utf8')
		self.cursor = conn.cursor ()
		if len(subjects)>0:
			for self.subject in subjects:
				cursor.execute("select ident from category where category=\""+self.subject+"\";")
				self.idents=cursor.fetchall()
				for self.ident in self.idents:
					self.contid+=1
					self.keyarea=str(self.contid)+":area"
					self.termbase[self.keyarea]=self.subject
					
					for self.lang in langs:
						cursor2.execute("select term from term where ident=\""+str(self.ident[0])+"\" and lang=\""+self.lang+"\";")
						self.terms=cursor2.fetchall()
						for self.term in self.terms:
							if not self.term[0].startswith("Category:") and len(self.term[0])>0:		
								self.key=str(str(self.contid)+":"+self.lang)
								if self.termbase.has_key(self.key):
									self.termbase[self.key]+=":"+str(self.term[0])
								else:
									self.termbase[self.key]=str(self.term[0])   



'''''''''''''''''''''   MAIN '''''''''''''''''''''''''''''

# command line options
parser = argparse.ArgumentParser(description='Create a dictionary from Terminologia Oberta glossaries', version='%prog 2.0')
parser.add_argument('termcat', metavar="TERMCAT_FILE",
                   help='the name of the file for the apertium dump or the directory where to find the files')
parser.add_argument('-l', "--lang", dest="lang",required=True,
				   help="the local language: es,ca,...", metavar="LANG")
parser.add_argument("-o", "--output", dest="outputfile",required=True,
                   help="a file to write the results", metavar="FILE") 
args = parser.parse_args()
 
if args.termcat==None:
	print "No input file or directory provided. Use -h to get help"
	sys.exit()

if args.lang==None:
	print "No target language provided. Use -h to get help"
	sys.exit()
 
if (args.outputfile==None):
    print "No output file provided. Use -h to get help"
    sys.exit()
 

tbxtools=TBXTools()
# read the files and get the information
if os.path.isdir(args.termcat):
	for infile in glob.glob(os.path.join(args.termcat,'*.xml')):
		tbxtools.read_TO(infile)
else: tbxtools.read_TO(args.termcat)

tbxtools.write_town(args.outputfile,"en",args.lang,"n")


