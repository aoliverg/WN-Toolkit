# copyright Antoni Oliver (2013) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# To run this program you need nltk (http://nltk.org) installed

#! /usr/bin/python
# -*- coding: utf-8 -*-


from __future__ import division
import codecs
import re
import operator
import sys, argparse
from nltk import FreqDist as fd
# command line options
parser = argparse.ArgumentParser(description='Synset - variant alignment algorithm', version='%prog 2.0')
parser.add_argument("-s", "--sc", dest="sensecorpus",required=True,
                  help="The sense-tagged corpus", metavar="FILE") 
parser.add_argument("-t", "--tc", dest="targetcorpus", required=True,
                  help="The target corpus, tagged with simple tags", metavar="FILE")
parser.add_argument("-o", "--output", dest="outputfile",required=True,
                  help="The output file", metavar="FILE")         
parser.add_argument("-i", "--index", dest="minindex",required=False,
                  help="The minimun index (freq of 1st candidate divided by freq of 2n candidate). Recommended higher than 1. Default: 2.5", metavar="VALUE", default=2.5)               
parser.add_argument("-f", "--fr", dest="freqrel",required=False,
                  help="The maximun number of times the synset frequency can be higher than the variant frequency. Default: 5", metavar="VALUE", default=5)               
                  
args = parser.parse_args()

senses=codecs.open(args.sensecorpus,"r",encoding="utf-8")
target=codecs.open(args.targetcorpus,"r",encoding="utf-8")
sortida=codecs.open(args.outputfile,"w",encoding="utf-8")
p = re.compile('[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]-[nvar]')

    
freqsynsets=fd()
freqvariants=fd()
    
indexsynsets={}
indexsentences={}
cont=0
while 1:
    linia=senses.readline()
    liniatarget=target.readline()
    if not linia:
        break 
    if not liniatarget:
        break 
    cont+=1
    linia=linia.rstrip()
    liniatarget=liniatarget.rstrip()
    indexsentences[str(cont)]=liniatarget
    tokens=linia.split(" ")
    for token in tokens:       
        if not p.match(token)==None:
            freqsynsets.inc(token)
            if indexsynsets.has_key(token):
                indexsynsets[token]+=":"+str(cont)
            else:
                indexsynsets[token]=str(cont)
    tokenstarget=liniatarget.split(" ")
    for tt in tokenstarget:
        freqvariants.inc(tt)
            
        
for key in freqsynsets:
    candidats={}
    pos=key[-1]
    sentences=indexsynsets[key].split(":")
    candidats=fd()
    for s in sentences:
        frase=indexsentences[s]
        tokens=frase.split(" ")
        for token in tokens:
            camps=token.split("|")
            if len(camps)>=2:
                lema=camps[0]
                pos2=camps[1]
                if pos2==pos:
                    candidats.inc(lema)                
    sorted_candidats = candidats.keys()   
    if len(sorted_candidats)>1 and candidats[sorted_candidats[0]]>candidats[sorted_candidats[1]]:
        while True:
            if len(sorted_candidats)>=2:
                index=int(candidats[sorted_candidats[0]])/int(candidats[sorted_candidats[1]])
            else:
                index=999999
            variant=sorted_candidats[0]
            
            if index >= float(args.minindex):
                index2=freqvariants[variant+"|"+pos]/freqsynsets[key]
                if index2<=float(args.freqrel):
                    cadena=key+"\t"+variant
                    print cadena
                    sortida.write(cadena+"\n")
                    break
            else:
                break
            sorted_candidats.pop(0)
            if len(sorted_candidats)==0:
                break            
            print "DELETED",variant
