#copyright Antoni Oliver (2014) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.

#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.

#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#version 2.0

import sys
import codecs

if len(sys.argv)<2:
    print "2 arguments must been provided: the path and name of the input file and the path and name of the output file."
    sys.exit()

fentrada=sys.argv[1]
fsortida=sys.argv[2]

print fentrada,">>>",fsortida

entrada=codecs.open(fentrada,"r",encoding="utf-8")
sortida=codecs.open(fsortida,"w",encoding="utf-8")
while 1:
    linia=entrada.readline()
    if not linia:
        break 
    linia=linia.rstrip()
    nl=[]
    tokens=linia.split(" ")
    for token in tokens:
        camps=token.split(":")
        if len(camps)>5:
            nl.append(camps[4])
        elif len(camps)>1:
            nl.append(camps[1])
        else:
            nl.append(camps[0])
    nlinia=" ".join(nl)
    sortida.write(nlinia+"\n")
