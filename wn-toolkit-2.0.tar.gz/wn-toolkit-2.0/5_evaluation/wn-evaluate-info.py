# copyright Antoni Oliver (2013) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import division
from nltk.corpus import wordnet as wnnltk
import codecs
import sys, argparse
import dbm

def offsetpos2synset(element):
    offset=int(element[0:8])
    pos=element[-1]
    s=wnnltk._synset_from_pos_and_offset(pos,offset)
    return s

wn30=dbm.open("wordnet30-eng", "r")

# command line options
parser = argparse.ArgumentParser(description='Evaluation algorithm. Two output files are generates:\n\tnoevaluated: information about non-evaluated variants\n\tincorrect.txt: information about the variants evaluated as incorrect', version='%prog 2.0')
parser.add_argument("-r", "--ref", dest="referencia",required=True,
                  help="The reference wordnet for evaluation in Open Multilingual WordNet format", metavar="FILE") 
parser.add_argument("-e", "--eva", dest="wneva", required=True,
                  help="The target WordNet to evaluate", metavar="FILE")
args = parser.parse_args()

wn={}
entrada=codecs.open(args.referencia,"r",encoding="utf-8")
while 1:
    linia=entrada.readline()
    if not linia:
        break 
    linia=linia.rstrip()
    camps=linia.split("\t")
    if len(camps)>=3:
        synset=camps[0]
        #synset=synset.replace("-","")
        variant=camps[2].lower()
        variant=variant.replace(" ","_")
        variant=variant.lower()
        if wn.has_key(synset):
            wn[synset].append(variant)
        else:
            array=[]
            array.append(variant)
            wn[synset]=array

correctes=0
totals=0
avaluats=0


correctesN=0
totalsN=0
avaluatsN=0

correctesV=0
totalsV=0
avaluatsV=0

correctesA=0
totalsA=0
avaluatsA=0

correctesR=0
totalsR=0
avaluatsR=0

nous=0

noeva=codecs.open("nonevaluated.txt","w",encoding="utf-8")
incorrectes=codecs.open("incorrect.txt","w",encoding="utf-8")

entrada=codecs.open(args.wneva,"r",encoding="utf-8")
while 1:
    totals+=1
    linia=entrada.readline()
    if not linia:
        break 
    linia=linia.rstrip()
    camps=linia.split("\t")
    if len(camps)>=2:
        synset=camps[0]
        if synset[-1]=="n":totalsN+=1
        elif synset[-1]=="v":totalsV+=1
        elif synset[-1]=="a":totalsA+=1
        elif synset[-1]=="r":totalsR+=1
        variant=camps[1].lower()
        
        if wn.has_key(synset):
            
            avaluats+=1
            if synset[-1]=="n":avaluatsN+=1
            elif synset[-1]=="v":avaluatsV+=1
            elif synset[-1]=="a":avaluatsA+=1
            elif synset[-1]=="r":avaluatsR+=1
            if variant.lower() in wn[synset]:
                correctes+=1
                if synset[-1]=="n":correctesN+=1
                elif synset[-1]=="v":correctesV+=1
                elif synset[-1]=="a":correctesA+=1
                elif synset[-1]=="r":correctesR+=1
            else:
                synset2=offsetpos2synset(synset)
                ve=[]
                for l in synset2.lemmas:
                    ve.append(l.name)
                variantseng=",".join(ve)
                definition=synset2.definition  
                cadena=synset+"\t"+variant+"\t"+",".join(wn[synset])+"\t"+variantseng+"\t"+definition
                incorrectes.write(cadena+"\n")
        else:
            nous+=1
            try:          
                synset2=offsetpos2synset(synset)
                ve=[]
                for l in synset2.lemmas:
                    ve.append(l.name)
                variantseng=",".join(ve)
                definition=synset2.definition    
                cadena=synset+"\t"+variant+"\t"+variantseng+"\t"+definition
                noeva.write(cadena+"\n")
            except:
                pass


print "TOTAL       :",totals
precisio=100*correctes/avaluats
print "PRECISION   :",("%.2f" % round(precisio,2))
print "-------"
print "NEW VARIANTS:",nous
