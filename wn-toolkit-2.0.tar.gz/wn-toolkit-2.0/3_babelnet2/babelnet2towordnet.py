#copyright Antoni Oliver (2014) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.

#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.

#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.

# version 2.0

import codecs
import sys

if len(sys.argv)<2:
    print "2 arguments must been provided:  the path and name of the output file and the language code.\nThe babelnet-2.0.0-core-dump file must be in the same directory of this program."
    sys.exit()

fsortida=sys.argv[1]
lang=sys.argv[2]

entrada=codecs.open("babelnet-2.0.0-core-dump","r",encoding="utf-8")
sortida=codecs.open(fsortida,"w",encoding="utf-8")
wordnet={}
cont=0
while 1:
    cont+=1
    linia=entrada.readline()
    if not linia:
        break
    linia=linia.rstrip()
    camps=linia.split("\t")
    if len(camps)>1:
        synset=camps[2]
        if synset=="":
            break
        synset=synset[0:8]+"-"+synset[-1]
        for camp in camps:
            if camp.startswith("WN:"+lang) and not synset=="": 
                trad=camp[6:].split(":")[0]
                trad=trad.split("_(")[0]                
                if not wordnet.has_key(synset):
                    wordnet[synset]=trad
                else:
                    wordnet[synset]+=":"+trad
            if camp.startswith("WIKI:"+lang) and not synset=="":
                trad=camp[8:].split(":")[0]
                trad=trad.split("_(")[0]  
                if not wordnet.has_key(synset):
                    wordnet[synset]=trad
                else:
                    wordnet[synset]+=":"+trad

for key in wordnet.keys():
    candidats=wordnet[key].split(":")
    tolower=False
    for candidat in candidats:
        if candidat==candidat.lower():tolower=True
    candidats2={}
    for candidat in candidats:
        if tolower:
            candidat=candidat.lower()
        candidat=candidat.replace(" ","_")
        candidats2[candidat]=1
    for candidat in sorted(candidats2.keys()):
        cadena=key+"\t"+candidat
        print cadena
        sortida.write(cadena+"\n")
            
