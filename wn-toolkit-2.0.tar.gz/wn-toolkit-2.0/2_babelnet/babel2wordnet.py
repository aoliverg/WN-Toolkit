#copyright Antoni Oliver (2012) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.

#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.

#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.

import re
import codecs
import sys, argparse, os

# command line options
parser = argparse.ArgumentParser(description='Creates a WordNet from BabelNet', version='%prog 2.0')
parser.add_argument('babelnet', metavar="BABEL_GlOSSES",
                   help='The path to the babel-glosses file')
parser.add_argument("-l", "--lang", dest="lang",required=True,
                  help="the target language: es, fr, ca...", metavar="LANG") 
parser.add_argument("-o", "--output", dest="outputfile",required=True,
                  help="a file to write the results", metavar="FILE") 
parser.add_argument("-d", "--diccionari", dest="diccionari",
                  help="a file containing a dictionary created from Wikipedia.", metavar="FILE")  
            
parser.add_argument("-w", "--wordnet", dest="wordnet",
                  help="The directory where the PWN data.noun file of PWN is located. Default: current directory. Useful for caps normalization.", metavar="FILE")                   
args = parser.parse_args()

babelnet=codecs.open(args.babelnet,"r",encoding="utf-8")

babelsynset=""
pwnsynset=""
engvariant=""
localvariant=""

localwordnet={}
englishwiki={}
while 1:
    linia=babelnet.readline()
    if not linia:
        break
    linia=linia.rstrip()
    if linia.startswith("bn:"):
        babelsynset=linia.replace("bn:","")
        if not engvariant=="":
            if englishwiki.has_key(pwnsynset):
                englishwiki[pwnsynset]+=":"+engvariant
            else:
                englishwiki[pwnsynset]=engvariant
        elif not localvariant=="":
            if localwordnet.has_key(pwnsynset):
                localwordnet[pwnsynset]+=":"+localvariant
            else:
                localwordnet[pwnsynset]=localvariant
            
        engvariant=""
        localvariant=""
    else:
        camps=linia.split("\t")
        if camps[0]=="EN" and camps[1]=="WIKIWN":
            pwnsynset=camps[2]
        elif camps[0]=="EN" and camps[1]=="WIKI":
            engvariant=camps[2]
            engvariant=engvariant.replace("_"," ")
        elif camps[0]==args.lang.upper() and camps[1]=="WIKI":
            localvariant=camps[2]
            localvariant=localvariant.replace("_"," ")

if args.diccionari:
    wikidiccionari={}
    wikidict=codecs.open(args.diccionari,"r",encoding="utf-8")
    while 1:
        linia=wikidict.readline()
        if not linia:
            break
        linia=linia.rstrip()
        camps=linia.split("\t")
        if len(camps)==3:
            eng=camps[0]
            loc=camps[2]
            eng=eng.replace(" ","_")
            loc=loc.replace(" ","_")
            if wikidiccionari.has_key(eng):
                wikidiccionari[eng]+=":"+loc
            else:
                wikidiccionari[eng]=loc
    for key in englishwiki.keys():
        if wikidiccionari.has_key(englishwiki[key]):
            if localwordnet.has_key(key):
                registrades=localwordnet[key].split(":")
                delenwiki=wikidiccionari[englishwiki[key]].split(":")
                for e in delenwiki:
                    if not e in registrades:
                        localwordnet[key]+=":"+e
            else:
                delenwiki=wikidiccionari[englishwiki[key]].split(":")
                for e in delenwiki:
                    if localwordnet.has_key(key):
                        localwordnet[key]+=":"+e
                    else:
                        localwordnet[key]=e
#caps normalization
uncapitalize={}
if args.wordnet:
    directory=args.wordnet+"/"
    uncapitalize={}
    files=["data.noun"]
    for f in files:
        f=directory+f
        if not os.path.isfile(f):
            print "WorNet files not found. Please use -d option."
            sys.exit()
        pwnf=codecs.open(f,"r",encoding="utf-8")
        cont=0
        while 1:
            line=pwnf.readline()
            if not line:
                break
            cont+=1
            if cont<30:
                continue
            line=line.rstrip()
            camps=line.split(" ")
            offset=camps[0]
            pos=camps[2]
            if pos=="s":pos="a"
            offsetpos=str(offset)+pos
            numvariants=camps[3]
            numvariants=int(numvariants,16)
            uncap=True
            for x in range(4,4+numvariants*2-1,2):
                if not camps[x]==camps[x].lower():
                    uncap=False
            uncapitalize[offsetpos]=uncap       
        
                        

sortida=codecs.open(args.outputfile,"w",encoding="utf-8")        
keyssort=localwordnet.keys()
keyssort.sort()
for key in keyssort:
    variants=localwordnet[key]
    if uncapitalize.has_key(key) and uncapitalize[key]:
        variants=variants.lower()
    cadena=key+"\t"+variants
    sortida.write(cadena+"\n")

    
