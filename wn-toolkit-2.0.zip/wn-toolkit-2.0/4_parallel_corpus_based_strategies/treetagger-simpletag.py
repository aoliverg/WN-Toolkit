import codecs
import sys
import os
import argparse

#!/usr/bin/env python
# -*- coding: utf-8 -*-
#       
#       Copyright 2012 Antoni Oliver <aoliverg@uoc.edu>
#       
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#       
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#       
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.
#       
# 

parser = argparse.ArgumentParser(description='Tags a text with simplified tagset using Tree Tagger (fre, deu, rus). To add more languages, simply edit this program.).', version='%prog 2.0')

parser.add_argument("-l", "--lang",required=True,dest="lang",
                  help="The ISO 3 letter code for the language", metavar="LANG") 
                  
parser.add_argument("-i", "--input",required=True,dest="inf",
                  help="The input file to tag", metavar="FILE") 
parser.add_argument("-o", "--output", dest="of",required=True,
                  help="The output file", metavar="FILE") 
args = parser.parse_args()

fe=args.inf
fs=args.of
lang=args.lang



entrada=codecs.open(fe,"r",encoding="utf-8")
sortida=codecs.open(fs,"w",encoding="utf-8")
tempnumber=codecs.open("tempnumber.txt","w",encoding="utf-8")

###ADD MORE LANGUAGES HERE

if lang=="fra" or lang=="fre":
    instruccio="tree-tagger-french-utf8 <tempnumber.txt >tempnumberana.txt"
elif lang=="deu":
    instruccio="tree-tagger-german-utf8 <tempnumber.txt >tempnumberana.txt"
elif lang=="rus":
    instruccio="tree-tagger-russian <tempnumber.txt >tempnumberana.txt"

###ADD ALSO INFORMATION HERE ABOUT NEW LANGUAGES
def simplifica(tag,lang):
    if lang=="fra" or lang=="fre":
        if tag.startswith("NOM"): st="n"
        elif tag.startswith("VER"):st="v"
        elif tag.startswith("ADJ"):st="a"
        elif tag.startswith("ADV"):st="r"
        else: st="c"
    if lang=="deu":
        if tag.startswith("N"): st="n"
        elif tag.startswith("VA"):st="c"
        elif tag.startswith("V"):st="v"
        elif tag.startswith("ADJ"):st="a"
        elif tag.startswith("ADV"):st="r"
        else: st="c"
    if lang=="rus":
        if tag.startswith("N"): st="n"
        elif tag.startswith("Va"):st="c"
        elif tag.startswith("Vm"):st="v"
        elif tag.startswith("A"):st="a"
        elif tag.startswith("R"):st="r"
        else: st="c"
    return st
   
cont=0
while 1:
    line=entrada.readline()
    if not line:
        break     
    cont+=1
    line=line.rstrip()
    cadena="<s id=\""+str(cont)+"\">"+line+"</s>"
    tempnumber.write(cadena+"\n")
tempnumber.close()
try:
    os.system(instruccio)    
except:
    print "ERROR TREETAGGER"
entrada2=codecs.open("tempnumberana.txt","r",encoding="utf-8") 
frase=""
lemes=""
while 1:
    linia=entrada2.readline()
    if not linia:
        break
    linia=linia.rstrip()
    if linia.startswith("</s>"):
        lemes=lemes.lstrip()
        lemes=lemes.rstrip()
        sortida.write(lemes+"\n")
        frase=""
        lemes=""
    elif linia.startswith("<p>"):
        fs.write(linia+"\n")
    elif not linia.startswith("<s"):
        camps=linia.split("\t")
        if len(camps)==3:
            forma=camps[0]
            tag=camps[1]
            lema=camps[2]
            if lema=="<unknown>":
                lema=forma
            frase=frase+" "+forma
            lemes=lemes+" "+lema+"|"+simplifica(tag,lang)
    
    
    
    

