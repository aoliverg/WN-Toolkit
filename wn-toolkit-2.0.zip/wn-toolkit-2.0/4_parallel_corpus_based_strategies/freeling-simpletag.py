#!/usr/bin/env python
# -*- coding: utf-8 -*-
#       
#       Copyright 2012 Antoni Oliver <aoliverg@uoc.edu>
#       
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#       
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#       
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.
#       
# 

import codecs
import sys
import os
import argparse



parser = argparse.ArgumentParser(description='Tags a text with simplified tagset using Freeling (eng, cat, spa, ita, por, rus, glg).', version='%prog 2.0')
parser.add_argument("-p", "--port",required=True,dest="port",
                  help="The port number used in Freeling as a server.", metavar="PORT") 
parser.add_argument("-l", "--lang",required=True,dest="lang",
                  help="The ISO 3 letter code for the language", metavar="LANG") 
                  
parser.add_argument("-i", "--input",required=True,dest="inf",
                  help="The input file to tag", metavar="FILE") 
parser.add_argument("-o", "--output", dest="of",required=True,
                  help="The output file", metavar="FILE") 
args = parser.parse_args()

port=args.port
fe=args.inf
fs=args.of
lang=args.lang



entrada=codecs.open(fe,"r",encoding="utf-8")
sortida=codecs.open(fs,"w",encoding="utf-8")
instruccio="analyzer_client "+str(port)+ "<tempsenses.txt >tempsensesana.txt"

def simplifica(tag,lang):
    if lang=="spa" or lang=="cat" or lang=="ita" or lang=="por" or lang=="glg":
        if tag.startswith("N"): st="n"
        elif tag.startswith("VA"):st="c"
        elif tag.startswith("V"):st="v"
        elif tag.startswith("A"):st="a"
        elif tag.startswith("R"):st="r"
        else: st="c"
    elif lang=="eng":
        if tag.startswith("N"): st="n"
        elif tag.startswith("V"):st="v"
        elif tag.startswith("J"):st="a"
        elif tag.startswith("R"):st="r"
        else: st="c"
    elif lang=="rus":
        if tag.startswith("N"): st="n"
        elif tag.startswith("V"):st="v"
        elif tag.startswith("A"):st="a"
        elif tag.startswith("D"):st="r"
        else: st="c"
    return st
    
cont=0
while 1:
    cont+=1
    print "CONT",cont,fe
    #if cont==100:
    #    break
    linia=entrada.readline()
    if not linia:
        break
    try:        
        linia=linia.rstrip()
        print linia
        temp=codecs.open("tempsenses.txt","w",encoding="utf-8")
        temp.write(linia+"\n")
        temp.close()
        try:
            os.system(instruccio)    
        except:
            print "ERROR SERVIDOR FREELING"
            break
            
        tempana=codecs.open("tempsensesana.txt","r",encoding="utf-8")
        liniesana=tempana.readlines()
        anaarray=[]

        for lana in liniesana:
            campslana=lana.rstrip().split(" ")
            
            if len(campslana)>=3:
                simpletag=simplifica(campslana[2],lang)
                lema=campslana[1]
                cadena=lema+"|"+simpletag
                anaarray.append(cadena)
                
        anastring=" ".join(anaarray)
        #sortida.write(linia+"\t"+anastring+"\n")
        print anastring
        print "-----------------------------_"
        sortida.write(anastring+"\n")

    except:
        print "ERROR",sys.exc_info()
    
    
    
    

