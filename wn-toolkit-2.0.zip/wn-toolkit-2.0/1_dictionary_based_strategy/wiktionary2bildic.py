#copyright Antoni Oliver (2012) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

#	This program is free software: you can redistribute it and/or modify
#	it under the terms of the GNU General Public License as published by
#	the Free Software Foundation, either version 3 of the License, or
#	(at your option) any later version.

#	This program is distributed in the hope that it will be useful,
#	but WITHOUT ANY WARRANTY; without even the implied warranty of
#	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#	GNU General Public License for more details.

#	You should have received a copy of the GNU General Public License
#	along with this program.  If not, see <http://www.gnu.org/licenses/>.

#CONFIGURATION VARIABLES

import re
import codecs
import sys, argparse

wiktionary={}

def sortAndUniq(input):
  output = []
  for x in input:
    if x not in output:
      output.append(x)
  output.sort()
  return output

def tractatrad(linia):
	trads=[]
	linia=linia.replace("; ",", ")
	linia=linia.replace("}} {{","}}, {{ ")
	for oc in linia.split(", "):
		oc=oc.split("\s")[0]
		if oc.startswith("{{") and oc.endswith("}}"):
			oc=oc.lstrip("{{")
			oc=oc.rstrip("}}")
			camps=oc.split("|")
			if len(camps)>=3:
				traduccio=camps[2]
				trads.append(traduccio)
		if oc.startswith("[[") and oc.endswith("]]"):
			oc=oc.lstrip("[[")
			oc=oc.rstrip("]]")
			camps=oc.split("|")
			if len(camps)>=3:
				traduccio=camps[2]
				trads.append(traduccio)
	return trads
		
def registra(key,translations):
	if wiktionary.has_key(key):
		translations=wiktionary[key]
		translations.extend(translations)		
	wiktionary[key]=sortAndUniq(translations)


# command line options
parser = argparse.ArgumentParser(description='Creates a bilingual dictionary from Wiktionary xml dumps', version='%prog 2.0')
parser.add_argument('wikipediadump', metavar="WIKTIONARY_DUMP",
                   help='Wiktionary xml dump file')
parser.add_argument("-l", "--lang", dest="lang",required=True,
                  help="the target language: Spanish, French, Catalan...", metavar="LANG") 
parser.add_argument("-o", "--output", dest="outputfile",required=True,
                  help="a file to write the results", metavar="FILE") 
args = parser.parse_args()


if (args.lang==None):
	print "No target language provided. Use -h to get help"
	sys.exit()

if (args.wikipediadump==None):
	print "No EN Wiktionary XML dump provided. Use -h to get help"
	sys.exit()

if args.outputfile==None:
	print "No output file provided. Use -h to get help"
	sys.exit()
else:
	of=codecs.open(args.outputfile,"w",encoding="utf-8")


entrada=codecs.open(args.wikipediadump,"r",encoding="utf-8")

inPage=False
inTranslation=False
categories=[]
traduccions={}

ident=1
langw1="* "+args.lang+": "
langw2="* [["+args.lang+"]]: "
pos=""
print langw1
print langw2
while 1:
	linia=entrada.readline()
	if not linia:
		break
	linia=linia.lstrip()
	linia=linia.rstrip()
	if linia.find("<page>")>-1:
		inPage=True
	if linia.find("</page>")>-1:
		inPage=False
		pos=""
		for lang, trad in traduccions.iteritems():
				if lang == args.lang:
					trad=trad
					cadena=title+"\t"+trad
					print cadena
					if args.outputfile:
						of.write(cadena+"\n")
					if args.database:
						try:
							db[title.encode("utf8")]=trad.encode("utf8")
						except:
							print "ERROR",cadena, sys.exc_info()
	
		categories=[]
		traduccions={}
		ident+=1
	if linia.find("<title>")>-1 and inPage:
		try:		
			match=re.match("<title>(.*)</title>",linia)
			title=match.group(1)
		except:
			print "ERROR 4", sys.exc_info()
			inPage=False
	if linia.find("===Noun===")>-1 and inPage:
		pos="n"
	if linia.find("===Proper noun===")>-1 and inPage:
		pos="np"
	if linia.find("===Verb===")>-1 and inPage:
		pos="v"
	if linia.find("===Adjective===")>-1 and inPage:
		pos="a"
	if linia.find("===Adverb===")>-1 and inPage:
		pos="r"
	if linia.startswith("====Translations===="):
		inTranslation=True
	elif linia.startswith("==="):
		inTranslation=False
	if linia.startswith(langw1) and inTranslation and not pos=="":
		linia=linia.lstrip(langw1)
		translations=tractatrad(linia)
		if len(translations)>0:
			cadena=title+"\t"+pos+"\t"+", ".join(translations)
			if not (cadena.find("{")>-1 or cadena.find("}")>-1):
				print cadena
				key=title+":"+pos
				registra(key,translations)
	
	if linia.startswith(langw2) and inTranslation and not pos=="":
		linia=linia.lstrip(langw2)
		translations=tractatrad(linia)
		if len(translations)>0:
			cadena=title+"\t"+pos+"\t"+", ".join(translations)
			if not (cadena.find("{")>-1 or cadena.find("}")>-1):
				print cadena
				key=title+":"+pos
				registra(key,translations)
				
keys=wiktionary.keys()
keys.sort()
for key in keys:
	cadena=key.split(":")[0]+"\t"+key.split(":")[1]+"\t"+":".join(wiktionary[key])
	print cadena
	of.write(cadena+"\n")

	
