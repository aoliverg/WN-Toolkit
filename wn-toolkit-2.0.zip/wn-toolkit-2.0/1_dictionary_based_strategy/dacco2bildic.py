# copyright Marta Contreras (2012) (Universitat Oberta de Catalunya - mcontrerasf@uoc.edu)
# and Antoni Oliver (2012) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /usr/bin/python
# -*- coding: utf-8 -*--


import xml.dom.minidom
from xml.dom.minidom import Node
import sys, argparse
import codecs
import os, glob
import csv, operator	



''''''''''''''''''''''''''''''' FUNCTIONS '''''''''''''''''''''''''''''''

# get the translation from the dictionary
def get_trad (node):
	trad = ""
	for node2 in node:
		node3 = node2.getElementsByTagName("translation")
		for node4 in node3:
			for node5 in node4.childNodes:
				if node5.nodeType == Node.TEXT_NODE:
					text = format_string (node5.data.strip())
					if text != "" and text != "-" and duplicate (text, trad) != "": 
						trad += duplicate (text, trad)[:-1] + ":"
	return trad


# delete extra formatting characters from the word
def format_string (par):
	par = delete_brackets(par)
	list = par.split("/")
	res = ""
	for i in range (0,par.count("/")+1):
		if list[i].strip() == "-": continue
		res += list[i].strip() + ":"
	return res[:-1]


# delete all the existing brackets from the word
def delete_brackets (par):
	try:
		if par.find ("(") != -1:
			res = par[:par.index ("(")].strip() + par[par.index (")")+1:].strip()
			if res.find ("(") != -1: return delete_brackets(res)
			else: return res
		else: return par	
	except: return "-"


def duplicate (orig, dest):
	sol = ""
	try:
		for par in orig.split(":"):
			if par not in dest.split(":"): sol += par + ":"
		return sol
	except: return ""


# save the result (english variant + category + list of translations) into an output file or database
def save_data (par1, categ1, trad1):
	try:
		res = par1.strip() + "\t" + categ1 + "\t" + trad1.strip() + "\n"
		of.write(res.encode('utf-8'))
	except: print "ERROR-SAVE", res, sys.exc_info()


def check_in (list1, list2):
	res = ""
	for par in list1.strip().split(":"):
		if par not in list2.strip().split(":"): 
			if res == "": res = par
			else: res = res + ":" + par
	return res


# re-read the output file to reorder it, delete repeated 
# and aggregate translations within the same word 
def order_file(inf, ouf):
	try:
		of = open(inf,"r")
		data = csv.reader(of, delimiter='\t')
		sortedlist = sorted(data, key=operator.itemgetter(0,1), reverse=False)
	
		of2 = open(ouf,"w")
		ant = sortedlist[0]
		for grup in sortedlist[1:]:
			res = check_in (grup[2], ant[2])
			if (ant[0].strip() == grup[0].strip() and ant[1].strip() == grup[1].strip() and ant[2].strip() != grup[2].strip()
				and res != ""):
				ant[2] = ant[2].strip() + ":" + res
				continue

			if ant[0].strip() != grup[0].strip() or ant[1].strip() != grup[1].strip():
				of2.write(ant[0].strip() + '\t' + ant[1].strip() + '\t' + ant[2].strip() + '\n')
				ant = grup

		of2.write(ant[0].strip() + '\t' + ant[1].strip() + '\t' + ant[2].strip() + '\n')
	
		of.close()
		os.remove(inf)
		of2.close()

	except: print "ERROR-ORD", sys.exc_info()
		


'''''''''''''''''''''   MAIN '''''''''''''''''''''''''''''

# command line options
parser = argparse.ArgumentParser(description='Creates a bilingual dictionary from Dacco dictionary', version='%prog 2.0')
parser.add_argument('dacco', metavar="DACCO_FILE",
                   help='folder where to find dacco files')
parser.add_argument("-o", "--output", dest="outputfile",required=True,
                  help="a file to write the results", metavar="FILE") 
args = parser.parse_args()

if args.dacco==None:
	print "No Dacco dictionary provided. Use -h to get help"
	sys.exit()


if args.outputfile==None:
    print "No output file provided. Use -h to get help"
    sys.exit()
 
of = open("temp-file.txt","w")


# read all files from the DACCO folder    
try:

	for infile in glob.glob(os.path.join(args.dacco,'*.dic')):

		# read each xml DACCO file
		doc = xml.dom.minidom.parse(infile)
		for node in doc.getElementsByTagName("Entry"):

			par = ""
			for node2 in node.childNodes:
				if node2.nodeType == Node.TEXT_NODE:
					par += node2.data + " "

			categ = ""
			node3 = node.getElementsByTagName("nouns")
			if node3 != []: 
				categ = "n"
				trad = get_trad(node3)
				trad = format_string(trad)
				save_data (format_string(par.strip()), categ, trad[:-1].strip())
			node3 = node.getElementsByTagName("verbs")
			if node3 != []: 
				categ = "v"
				trad = get_trad(node3)
				trad = format_string(trad)
				save_data (format_string(par.strip()), categ, trad[:-1].strip())
			node3 = node.getElementsByTagName("adjectives")
			if node3 != []: 
				categ = "a"
				trad = get_trad(node3)
				trad = format_string(trad)
				save_data (format_string(par.strip()), categ, trad[:-1].strip())
			node3 = node.getElementsByTagName("adverbs")
			if node3 != []: 
				categ = "r"
				trad = get_trad(node3)
				trad = format_string(trad)
				save_data (format_string(par.strip()), categ, trad[:-1].strip())

except: print "ERROR", sys.exc_info()


# close 
if args.outputfile: 
	of.close()
	order_file("temp-file.txt", args.outputfile)

    



