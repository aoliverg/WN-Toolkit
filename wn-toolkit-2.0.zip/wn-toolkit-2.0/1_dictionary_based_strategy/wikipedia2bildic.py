#copyright Antoni Oliver (2012) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation, either version 3 of the License, or
#    (at your option) any later version.

#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.

#    You should have received a copy of the GNU General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.

#CONFIGURATION VARIABLES

import re
import codecs
import sys, argparse

# command line 
parser = argparse.ArgumentParser(description='Creates a bilingual dictionary from Wikipedia xml dumps', version='%prog 2.0')
parser.add_argument('wikipediadump', metavar="WIKIPEDIA_DUMP",
                   help='Wikipedia xml dump file')
parser.add_argument("-l", "--lang", dest="lang",required=True,
                  help="the target language: es, fr, ca...", metavar="LANG") 
parser.add_argument("-o", "--output", dest="outputfile",required=True,
                  help="a file to write the results", metavar="FILE") 
args = parser.parse_args()


if (args.lang==None):
    print "No options provided. Use -h to get help"
    sys.exit()

if (args.wikipediadump==None):
    print "No EN Wikipedia XML dump provided. Use -h to get help"
    sys.exit()

if args.outputfile:
    of=codecs.open(args.outputfile,"w",encoding="utf-8")


entrada=codecs.open(args.wikipediadump,"r",encoding="utf-8")

inPage=False
categories=[]
traduccions={}
ident=1
while 1:
    
    linia=entrada.readline()
    if not linia:
        break
    linia=linia.lstrip()
    linia=linia.rstrip()
    if linia.find("<page>")>-1:
        inPage=True
    if linia.find("</page>")>-1:
        inPage=False
        for lang, trad in traduccions.iteritems():
                if lang == args.lang:
                    trad=trad
                    cadena=title+"\tn\t"+trad
                    print cadena
                    if args.outputfile:
                        of.write(cadena+"\n")
    
        categories=[]
        traduccions={}
        ident+=1
    if linia.find("<title>")>-1 and inPage:
        try:        
            match=re.match("<title>(.*)</title>",linia)
            title=match.group(1)
        except:
            print "ERROR 4", sys.exc_info()
            inPage=False
    if inPage:
        if linia.startswith("[[") and linia.endswith("]]") and not linia.startswith("[[Image:") and not linia.startswith("[[File:") and linia.find("<comment>")==-1 and linia.find("!--")==-1:        
            match=re.match("\[\[(.*):(.*)\]\]",linia)
            if match != None:
                try:
                    codi=match.group(1)
                    traduccio=match.group(2)
                    traduccions[codi]=traduccio
                except:
                    print "ERROR6", sys.exc_info()

    
