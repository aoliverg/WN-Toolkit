#!/usr/bin/env python
# -*- coding: utf-8 -*-
#       
#       Copyright 2012 Antoni Oliver <aoliverg@uoc.edu>
#       
#       This program is free software; you can redistribute it and/or modify
#       it under the terms of the GNU General Public License as published by
#       the Free Software Foundation; either version 2 of the License, or
#       (at your option) any later version.
#       
#       This program is distributed in the hope that it will be useful,
#       but WITHOUT ANY WARRANTY; without even the implied warranty of
#       MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#       GNU General Public License for more details.
#       
#       You should have received a copy of the GNU General Public License
#       along with this program; if not, write to the Free Software
#       Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#       MA 02110-1301, USA.
#       
#       

import sys, argparse
import codecs

'''''''''''''''''''''   MAIN '''''''''''''''''''''''''''''

# command line options
parser = argparse.ArgumentParser(description='Translates PWN variants with bilingual dictionaries.', version='%prog 1.0')
parser.add_argument("-d", "--dictionary",required=True,dest="dictionary",
                  help="The dictionary to be used.", metavar="FILE") 
parser.add_argument("-i", "--input",required=True,dest="inf",
                  help="The input file containig the variants to be translated (createmonosemicwordlistprogram.py can be used to generate the input files)", metavar="FILE") 
parser.add_argument("-o", "--output", dest="of",required=True,
                  help="The output file containig the translated variants", metavar="FILE") 
args = parser.parse_args()


if args.dictionary==None:
    print "A dictionary file must be given. Use -h to get help"
    sys.exit()
else:
    dictionary=args.dictionary

    
if args.inf==None:
    print "An input file must be given. Use -h to get help"
    sys.exit()
else:
    inf=args.inf
    
if args.of==None:
    print "An output file must be given. Use -h to get help"
    sys.exit()
else:
    of=args.of
    
    

	
print "Dictionary to be used:",dictionary
print "Intput file:",inf
print "Output file:",of

db = {}
diccionari=codecs.open(dictionary,"r",encoding="utf-8")
entrada=codecs.open(inf,"r",encoding="utf-8")
sortida=codecs.open(of,"w",encoding="utf-8")

for linia in diccionari.readlines():
	linia=linia.rstrip()
	camps=linia.split("\t")
	pos=camps[1]
	if pos=="np": pos="n"
	w1pos=camps[0]+":"+pos
	db[w1pos]=camps[2]

for linia in entrada.readlines():
	linia=linia.rstrip()
	camps=linia.split("\t")
	offsetpos=camps[0]
	pos=offsetpos[-1]
	varianteng=camps[1]
	variantengmod=varianteng.replace("_"," ")+":"+pos
	if db.has_key(variantengmod):
		varianttradmodarray=db[variantengmod].split(":")
		for varianttradmod in varianttradmodarray:
			varianttrad=varianttradmod.replace(" ","_")
			print offsetpos,varianttrad
			cadena=offsetpos+"\t"+varianttrad
			sortida.write(cadena+"\n")

	




