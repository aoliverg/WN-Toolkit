# copyright Antoni Oliver (2012) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /usr/bin/python
# -*- coding: utf-8 -*-


import sys, argparse
import codecs
import os.path


'''''''''''''''''''''   MAIN '''''''''''''''''''''''''''''

# command line options
parser = argparse.ArgumentParser(description='Monosemic variants extraction', version='%prog 2.0')
parser.add_argument("-d", "--directory", dest="directory",
                  help="The directory where the data.adj, data.adv, data.noun, data.verb, index.adj, index.adv, index.noun and index.verb files of PWN are located. Default: current directory", metavar="DIRECTORY") 
parser.add_argument("-p", "--prefix", dest="prefix",
                  help="The prefix for the name of the output files: prefix.txt, prefix-maj.txr, prefix-min.txt. Default: pwn", metavar="STRING") 
args = parser.parse_args()


if args.directory==None:
    directory=""
else:
    directory=args.directory+"/"

if args.prefix==None:
    prefix="pwn"
else:
    prefix=args.prefix
    
nof=prefix+".txt"
nofmin=prefix+"-min.txt"
nofmaj=prefix+"-maj.txt"

of=codecs.open(nof,"w",encoding="utf-8")
ofmin=codecs.open(nofmin,"w",encoding="utf-8")
ofmaj=codecs.open(nofmaj,"w",encoding="utf-8")

#variants are lower cased in index.* files so case must be recorded from data.* files

variants={}
files=["data.adj","data.adv","data.noun","data.verb"]
for f in files:
    f=directory+f
    if not os.path.isfile(f):
        print "WorNet files not found. Please use -d option to specify the PWN directory or -h to get help."
        sys.exit()
    pwnf=codecs.open(f,"r",encoding="utf-8")
    cont=0
    while 1:
        line=pwnf.readline()
        if not line:
            break
        cont+=1
        if cont<30:
            continue
        line=line.rstrip()
        camps=line.split(" ")
        offset=camps[0]
        pos=camps[2]
        if pos=="s":pos="a"
        offsetpos=str(offset)+"-"+pos
        numvariants=camps[3]
        numvariants=int(numvariants,16)
        av={}
        for x in range(4,4+numvariants*2-1,2):
            av[camps[x].lower()]=camps[x]
        
        variants[offsetpos]=av


files=["index.adj","index.adv","index.noun","index.verb"]
for f in files:
    f=directory+"/"+f
    if not os.path.isfile(f):
        print "WorNet files not found. Please use -d option to specify the PWN directory or -h to get help."
        sys.exit()
    pwnf=codecs.open(f,"r",encoding="utf-8")
    cont=0
    while 1:
        line=pwnf.readline()
        if not line:
            break
        cont+=1
        if cont<30:
            continue
        line=line.rstrip()
        camps=line.split(" ")
        word=camps[0]
        pos=camps[1]
        if pos=="s":pos="a"
        senses=camps[2]
        if senses=="1":
            offset=camps[-1]
            offsetpos=str(offset)+"-"+pos
            if variants.has_key(offsetpos):
                if variants[offsetpos].has_key(word):
                    variant=variants[offsetpos][word]
                    cadena=offsetpos+"\t"+variant
                    of.write(cadena+"\n")
                    if variant==variant.lower():
                        ofmin.write(cadena+"\n")
                    else:
                        ofmaj.write(cadena+"\n")
