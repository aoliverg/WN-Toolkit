# copyright Antoni Oliver (2013) (Universitat Oberta de Catalunya - aoliverg@uoc.edu)

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

#! /usr/bin/python
# -*- coding: utf-8 -*-

from __future__ import division
import codecs
import sys, argparse

# command line options
parser = argparse.ArgumentParser(description='Evaluation algorithm', version='%prog 2.0')
parser.add_argument("-r", "--ref", dest="referencia",required=True,
                  help="The reference wordnet for evaluation in Open Multilingual WordNet format", metavar="FILE") 
parser.add_argument("-e", "--eva", dest="wneva", required=True,
                  help="The target WordNet to evaluate", metavar="FILE")
args = parser.parse_args()

wn={}
entrada=codecs.open(args.referencia,"r",encoding="utf-8")
while 1:
    linia=entrada.readline()
    if not linia:
        break 
    linia=linia.rstrip()
    camps=linia.split("\t")
    if len(camps)>=3:
        synset=camps[0]
        variant=camps[2]
        variant=variant.replace(" ","_")
        variant=variant.lower()
        if wn.has_key(synset):
            wn[synset].append(variant)
        else:
            array=[]
            array.append(variant)
            wn[synset]=array

t=0

correctes=0
totals=0

correctesN=0
totalsN=0

correctesV=0
totalsV=0

correctesA=0
totalsA=0

correctesR=0
totalsR=0

entrada=codecs.open(args.wneva,"r",encoding="utf-8")
while 1:
    t+=1
    linia=entrada.readline()
    if not linia:
        break 
    linia=linia.rstrip()
    camps=linia.split("\t")
    synset=camps[0]
    variant=camps[1]    
    if wn.has_key(synset):
        totals+=1
        if synset[-1]=="n":totalsN+=1
        elif synset[-1]=="v":totalsV+=1
        elif synset[-1]=="a":totalsA+=1
        elif synset[-1]=="r":totalsR+=1

        if variant.lower() in wn[synset]:
            correctes+=1
            if synset[-1]=="n":correctesN+=1
            elif synset[-1]=="v":correctesV+=1
            elif synset[-1]=="a":correctesA+=1
            elif synset[-1]=="r":correctesR+=1
        


print "TOTAL      :",t
print "EVALUATED  :",totals
precisio=100*correctes/totals
print "PRECISION  :",("%.2f" % round(precisio,2))
if totalsN>0:
    precisioN=100*correctesN/totalsN
else:
    precisioN=0
print "PRECISION N:",("%.2f" % round(precisioN,2))
if totalsV>0:
    precisioV=100*correctesV/totalsV
else:
    precisioV=0
print "PRECISION V:",("%.2f" % round(precisioV,2))
if totalsA>0:
    precisioA=100*correctesA/totalsA
else:
    precisioA=0
print "PRECISION A:",("%.2f" % round(precisioA,2))
if totalsR>0:
    precisioR=100*correctesR/totalsR
else:
    precisioR=0
print "PRECISION R:",("%.2f" % round(precisioR,2))

#print str(t)+"\t"+str(totals)+"\t"+str("%.2f" % round(precisio,2))+"\t"+str("%.2f" % round(precisioN,2))+"\t"+str("%.2f" % round(precisioV,2))+"\t"+str("%.2f" % round(precisioA,2))+"\t"+str("%.2f" % round(precisioR,2))
